package com.cg.controller;

public class SpringRestController {
	public String sayHello(@)

}
