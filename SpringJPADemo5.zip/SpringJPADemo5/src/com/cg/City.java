package com.cg;

public class City {
	private String name;
	private String city;
	private int population;

}
