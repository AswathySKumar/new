package com.cg;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.sun.scenario.effect.Blend.Mode;

@Controller
@RequestMapping(value="user")
public class UserController {
	ArrayList<String> cityList;
	ArrayList<String> skillList;
	
	@RequestMapping(value="showLogin")
	public String prepareLogin(Model model){
		model.addAttribute("login",new Login());
		return "login";
	}
	@RequestMapping(value="checkLogin")
	public ModelAndView checkLogin(@ModelAttribute("login")Login login){
		//String username="aswathy";
		//String password="aswathy";
		return new ModelAndView("loginSuccess","username",login.getUsername());
	
	}
	@RequestMapping(value="showRegister")
	public String prepareRegister(Model model){
		cityList=new ArrayList<String>();
		cityList.add("mumbai");
		cityList.add("bangalore");
		cityList.add("chennai");
		cityList.add("delhi");
		skillList=new ArrayList<String>();
		skillList.add("java");
		skillList.add("struts");
		skillList.add("spring");
		skillList.add("hibernate");
		model.addAttribute("cityList", cityList);
		model.addAttribute("skillList", skillList);
		
		model.addAttribute("user",new User());
		return "register";
	}
	@RequestMapping(value="checkRegister")
	public String checkRegister(@ModelAttribute("user")@Valid User user,BindingResult result,Model model)
	{
		if(result.hasErrors()){
			System.out.println("Error");
			model.addAttribute("cityList",cityList);
			model.addAttribute("skillList", skillList);
			return "register";
			
		}
		else
		{
			
			model.addAttribute("user",user);
			System.out.println("valid dd");
			
			
		return "registerSuccess";
		
	}
	}
}
